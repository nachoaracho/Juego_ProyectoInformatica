package mapa;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import mapa.cuadro.Cuadro;

public class MapaCargado extends Mapa{

	private int[] pixeles;
	
	public MapaCargado(String ruta) {
		super(ruta);
	}
	
	protected void cargarMapa(String ruta) {
		try {
			BufferedImage imagen= ImageIO.read(MapaCargado.class.getResource(ruta));
			
			ancho=imagen.getWidth();
			alto=imagen.getHeight();
			
			catalogo=new Cuadro[ancho*alto];
			pixeles=new int[ancho*alto];
			
			imagen.getRGB(0, 0, ancho, alto, pixeles, 0, ancho);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	protected void generarMapa() {
		for(int i=0;i<pixeles.length;i++) {
			switch(pixeles[i]) {
			case 0xffd7d7db:
				catalogo[i]=Cuadro.concreto;
				continue;
			case 0xff57b88f:
				catalogo[i]=Cuadro.PASTO1;
				continue;
			case 0xff9bcebd:
				catalogo[i]=Cuadro.PASTO2;
				continue;
			case 0xffda4b5e:
				catalogo[i]=Cuadro.FLORROJA1;
				continue;
			case 0xffca344c:
				catalogo[i]=Cuadro.FLORROJA2;
				continue;
			case 0xff861115:
				catalogo[i]=Cuadro.FLORROJA3;
				continue;
			case 0xff5289c7:
				catalogo[i]=Cuadro.FLORAZUL1;
				continue;
			case 0xff2f488d:
				catalogo[i]=Cuadro.FLORAZUL2;
				continue;
			case 0xff30226e:
				catalogo[i]=Cuadro.FLORAZUL3;
				continue;
			case 0xffe3d79e:
				catalogo[i]=Cuadro.FLORAMARILLA1;
				continue;
			case 0xffd8b040:
				catalogo[i]=Cuadro.BANQUETA1;
				continue;
			case 0xffb19039:
				catalogo[i]=Cuadro.BANQUETA2;
				continue;
			case 0xff1f2f38:
				catalogo[i]=Cuadro.BANQUETA3;
				continue;
			case 0xffbda14a:
				catalogo[i]=Cuadro.BANQUETA4;
				continue;
			case 0xff787888:
				catalogo[i]=Cuadro.ASFALTO1;
				continue;
			case 0xfff8f8fb:
				catalogo[i]=Cuadro.ASFALTO2;
				continue;
			case 0xffceced1:
				catalogo[i]=Cuadro.ASFALTO3;
				continue;
			case 0xff4a1717:
				catalogo[i]=Cuadro.BARDAD;
				continue;
			case 0xff9a888a:
				catalogo[i]=Cuadro.BARDAU;
				continue;
			case 0xffbababe:
				catalogo[i]=Cuadro.ENTRADA00;
				continue;
			case 0xff762727:
				catalogo[i]=Cuadro.ENTRADA10;
				continue;
			case 0xffb8b8bc:
				catalogo[i]=Cuadro.ENTRADA20;
				continue;
			case 0xff4e1919:
				catalogo[i]=Cuadro.ENTRADA01;
				continue;
			case 0xff451515:
				catalogo[i]=Cuadro.ENTRADA21;
				continue;
			case 0xff404868:
				catalogo[i]=Cuadro.ENTRADA11;
				continue;
			case 0xff622727:
				catalogo[i]=Cuadro.ENTRADA02;
				continue;
			case 0xff776c6d:
				catalogo[i]=Cuadro.ENTRADA12;
				continue;
			case 0xff592a2a:
				catalogo[i]=Cuadro.ENTRADA22;
				continue;
			default:
				catalogo[i]=Cuadro.VACIO;
			}
		}
	}
}
