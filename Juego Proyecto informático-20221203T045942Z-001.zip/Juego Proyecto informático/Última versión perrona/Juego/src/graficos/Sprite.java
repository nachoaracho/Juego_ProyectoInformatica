package graficos;

public class Sprite {
	private final int lado;
	
	private int x;
	private int y;
	
	public int[] pixeles;
	private HojaSprites hoja;
	
	//Coleccion de sprites
	public static final Sprite VACIO=new Sprite(32,0);
	public static final Sprite concreto=new Sprite(16,0,0,HojaSprites.entrada);
	////pastos
	public static final Sprite PASTO1=new Sprite(16,1,0,HojaSprites.entrada);
	public static final Sprite PASTO2=new Sprite(16,2,0,HojaSprites.entrada);
	////flores
	public static final Sprite FLORROJA1=new Sprite(16,3,0,HojaSprites.entrada);
	public static final Sprite FLORROJA2=new Sprite(16,4,0,HojaSprites.entrada);
	public static final Sprite FLORROJA3=new Sprite(16,5,0,HojaSprites.entrada);
	public static final Sprite FLORAZUL1=new Sprite(16,6,0,HojaSprites.entrada);
	public static final Sprite FLORAZUL2=new Sprite(16,7,0,HojaSprites.entrada);
	public static final Sprite FLORAZUL3=new Sprite(16,8,0,HojaSprites.entrada);
	public static final Sprite FLORAMARILLA1=new Sprite(16,9,0,HojaSprites.entrada);
	////banquetas
	public static final Sprite BANQUETA1=new Sprite(16,4,2,HojaSprites.entrada);
	public static final Sprite BANQUETA2=new Sprite(16,5,2,HojaSprites.entrada);
	public static final Sprite BANQUETA3=new Sprite(16,6,2,HojaSprites.entrada);
	public static final Sprite BANQUETA4=new Sprite(16,7,2,HojaSprites.entrada);
	////asfalto
	public static final Sprite ASFALTO1=new Sprite(16,4,3,HojaSprites.entrada);
	public static final Sprite ASFALTO2=new Sprite(16,5,3,HojaSprites.entrada);
	public static final Sprite ASFALTO3=new Sprite(16,6,3,HojaSprites.entrada);
	////barda
	public static final Sprite BARDAD=new Sprite(16,8,2,HojaSprites.entrada);
	public static final Sprite BARDAU=new Sprite(16,9,2,HojaSprites.entrada);
	////piezas de la barda
	public static final Sprite ENTRADA00=new Sprite(16,7,3,HojaSprites.entrada);
	public static final Sprite ENTRADA10=new Sprite(16,8,3,HojaSprites.entrada);
	public static final Sprite ENTRADA20=new Sprite(16,9,3,HojaSprites.entrada);
	public static final Sprite ENTRADA01=new Sprite(16,7,4,HojaSprites.entrada);
	public static final Sprite ENTRADA11=new Sprite(16,8,4,HojaSprites.entrada);
	public static final Sprite ENTRADA21=new Sprite(16,9,4,HojaSprites.entrada);
	public static final Sprite ENTRADA02=new Sprite(16,7,5,HojaSprites.entrada);
	public static final Sprite ENTRADA12=new Sprite(16,8,5,HojaSprites.entrada);
	public static final Sprite ENTRADA22=new Sprite(16,9,5,HojaSprites.entrada);
	//fin de la coleccion
	
	public Sprite(final int lado, final int columna, final int fila, final HojaSprites hoja) {
		this.lado=lado;
		
		pixeles=new int[lado*lado];
				
		this.x=columna *lado;
		this.y=fila*lado;
		this.hoja=hoja;
		
		for(int y=0;y<lado;y++){
			for(int x=0;x<lado;x++) {
				pixeles[x+y*lado]=hoja.pixeles[(x+this.x)+(y+this.y)*hoja.obtenAncho()];
			}
		}
	}
	
	public Sprite(final int lado, final int color) {
		this.lado=lado;
		pixeles=new int[lado*lado];
		
		for(int i=0;i<pixeles.length;i++) {
			pixeles[i]=color;
		}
	}
	
	public int obtenLado() {
		return lado;
	}
}
