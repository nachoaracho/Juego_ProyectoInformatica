package mapa;

import graficos.Pantalla;
import mapa.cuadro.Cuadro;

public abstract class Mapa {
	protected int ancho;
	protected int alto;
	
	protected int[] cuadros;
	
	public Mapa(int ancho, int alto) {
		this.ancho=ancho;
		this.alto=alto;
		
		cuadros = new int[ancho*alto];
		generarMapa();
	}
	
	public Mapa(String ruta) {
		cargarMapa(ruta);
	}
	
	protected void generarMapa() {
		
	}
	
	private void cargarMapa(String ruta) {
		
	}
	
	public void actualizar() {
		
	}
	
	//Temporal
	public void mostrar(int compensacionX, int compensacionY, Pantalla pantalla) {
		
		pantalla.estableceDiferencia(compensacionX, compensacionY);
		
		int o =compensacionX >> 4;
		int es=(compensacionX+pantalla.obtenerAncho()+Cuadro.LADO) >>4;
		int n=compensacionY >>4;
		int s=(compensacionY+pantalla.obtenerAlto()+Cuadro.LADO) >>4;
		
		for(int y=n;y<s;y++) {
			for(int x=o; x<es;x++) {
				obtenCuadro(x,y).mostrar(x, y, pantalla);
			}
		}
	}
	//fin temporal
	
	public Cuadro obtenCuadro(final int x,final int y) {
		if(x<0||y<0||x>=ancho||y>=alto) {
			return Cuadro.VACIO;
		}
		
		switch (cuadros[x+y*ancho]) {
		case 0:
			return Cuadro.concreto;
		case 1:
			return Cuadro.PASTO1;
		case 2:
			return Cuadro.PASTO2;
		case 3:
			return Cuadro.FLORROJA1;
		case 4:
			return Cuadro.FLORROJA2;
		case 5:
			return Cuadro.FLORROJA3;
		case 6:
			return Cuadro.FLORAZUL1;
		case 7:
			return Cuadro.FLORAZUL2;
		case 8:
			return Cuadro.FLORAZUL3;
		case 9:
			return Cuadro.FLORAMARILLA1;
		case 10:
			return Cuadro.BANQUETA1;
		case 11:
			return Cuadro.BANQUETA2;
		case 12:
			return Cuadro.BANQUETA3;
		case 13:
			return Cuadro.BANQUETA4;
		case 14:
			return Cuadro.ASFALTO1;
		case 15:
			return Cuadro.ASFALTO2;
		case 16:
			return Cuadro.ASFALTO3;
		case 17:
			return Cuadro.BARDAD;
		case 18:
			return Cuadro.BARDAU;
		case 19:
			return Cuadro.ENTRADA00;
		case 20:
			return Cuadro.ENTRADA10;
		case 21:
			return Cuadro.ENTRADA20;
		case 22:
			return Cuadro.ENTRADA01;
		case 23:
			return Cuadro.ENTRADA11;
		case 24:
			return Cuadro.ENTRADA21;
		case 25:
			return Cuadro.ENTRADA02;
		case 26:
			return Cuadro.ENTRADA12;
		case 27:
			return Cuadro.ENTRADA22;
		default:
			return Cuadro.VACIO;
		}
	}
}
