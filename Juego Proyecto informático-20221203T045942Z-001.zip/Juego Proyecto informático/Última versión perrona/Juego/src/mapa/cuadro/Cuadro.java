package mapa.cuadro;

import graficos.Pantalla;
import graficos.Sprite;

public class Cuadro {
	public int x;
	public int y;
	
	public Sprite sprite;
	
	public static final int LADO=16;
	
	//Coleccion de cuadros
	public static final Cuadro VACIO=new Cuadro(Sprite.VACIO);
	public static final Cuadro concreto= new Cuadro(Sprite.concreto);
	public static final Cuadro PASTO1=new Cuadro(Sprite.PASTO1);
	public static final Cuadro PASTO2= new Cuadro(Sprite.PASTO2);
	public static final Cuadro FLORROJA1=new Cuadro(Sprite.FLORROJA1);
	public static final Cuadro FLORROJA2=new Cuadro(Sprite.FLORROJA2);
	public static final Cuadro FLORROJA3=new Cuadro(Sprite.FLORROJA3);
	public static final Cuadro FLORAZUL1=new Cuadro(Sprite.FLORAZUL1);
	public static final Cuadro FLORAZUL2=new Cuadro(Sprite.FLORAZUL2);
	public static final Cuadro FLORAZUL3=new Cuadro(Sprite.FLORAZUL3);
	public static final Cuadro FLORAMARILLA1=new Cuadro(Sprite.FLORAMARILLA1);
	public static final Cuadro BANQUETA1=new Cuadro(Sprite.BANQUETA1);
	public static final Cuadro BANQUETA2=new Cuadro(Sprite.BANQUETA2);
	public static final Cuadro BANQUETA3=new Cuadro(Sprite.BANQUETA3);
	public static final Cuadro BANQUETA4=new Cuadro(Sprite.BANQUETA4);
	public static final Cuadro ASFALTO1=new Cuadro(Sprite.ASFALTO1);
	public static final Cuadro ASFALTO2=new Cuadro(Sprite.ASFALTO2);
	public static final Cuadro ASFALTO3=new Cuadro(Sprite.ASFALTO3);
	public static final Cuadro BARDAD=new Cuadro(Sprite.BARDAD);
	public static final Cuadro BARDAU=new Cuadro(Sprite.BARDAU);
	public static final Cuadro ENTRADA00=new Cuadro(Sprite.ENTRADA00);
	public static final Cuadro ENTRADA10=new Cuadro(Sprite.ENTRADA10);
	public static final Cuadro ENTRADA20=new Cuadro(Sprite.ENTRADA20);
	public static final Cuadro ENTRADA01=new Cuadro(Sprite.ENTRADA01);
	public static final Cuadro ENTRADA11=new Cuadro(Sprite.ENTRADA11);
	public static final Cuadro ENTRADA21=new Cuadro(Sprite.ENTRADA21);
	public static final Cuadro ENTRADA02=new Cuadro(Sprite.ENTRADA02);
	public static final Cuadro ENTRADA12=new Cuadro(Sprite.ENTRADA12);
	public static final Cuadro ENTRADA22=new Cuadro(Sprite.ENTRADA22);	
	//fin coleccion
	
	public Cuadro(Sprite sprite) {
		this.sprite=sprite;
	}
	
	public void mostrar(int x, int y, Pantalla pantalla) {
		pantalla.mostrarCuadro(x << 4, y << 4, this);
	}
	
	public boolean solido() {
		return false;
	}
}
