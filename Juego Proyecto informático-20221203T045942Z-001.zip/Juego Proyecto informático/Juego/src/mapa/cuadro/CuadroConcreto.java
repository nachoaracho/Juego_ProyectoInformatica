package mapa.cuadro;

import graficos.Pantalla;
import graficos.Sprite;

public class CuadroConcreto extends Cuadro{
	public CuadroConcreto(Sprite sprite) {
		super(sprite);
	}
	
}
