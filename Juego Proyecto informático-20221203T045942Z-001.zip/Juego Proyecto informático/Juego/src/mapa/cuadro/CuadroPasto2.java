package mapa.cuadro;

import graficos.Sprite;

public class CuadroPasto2 extends Cuadro {

	public CuadroPasto2(Sprite sprite) {
		super(sprite);
	}

}
