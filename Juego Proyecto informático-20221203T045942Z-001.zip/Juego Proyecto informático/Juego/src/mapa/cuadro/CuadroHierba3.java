package mapa.cuadro;

import graficos.Sprite;

public class CuadroHierba3 extends Cuadro{

	public CuadroHierba3(Sprite sprite) {
		super(sprite);
		// TODO Auto-generated constructor stub
	}

}
