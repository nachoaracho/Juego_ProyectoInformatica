package mapa.cuadro;

import graficos.Sprite;

public class CuadroArbusto extends Cuadro {

	public CuadroArbusto(Sprite sprite) {
		super(sprite);
		// TODO Auto-generated constructor stub
	}

}
