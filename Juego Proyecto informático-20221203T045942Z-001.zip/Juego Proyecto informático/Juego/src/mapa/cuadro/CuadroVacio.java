package mapa.cuadro;

import graficos.Pantalla;
import graficos.Sprite;

public class CuadroVacio extends Cuadro {
	public CuadroVacio(Sprite sprite) {
		super(sprite);
	}
	
}
