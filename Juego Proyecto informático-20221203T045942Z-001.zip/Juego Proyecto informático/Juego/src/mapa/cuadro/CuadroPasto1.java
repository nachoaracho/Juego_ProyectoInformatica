package mapa.cuadro;

import graficos.Sprite;

public class CuadroPasto1 extends Cuadro{

	public CuadroPasto1(Sprite sprite) {
		super(sprite);
	}

}
