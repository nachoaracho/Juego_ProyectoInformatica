package mapa.cuadro;

import graficos.Sprite;

public class CuadroHierba2 extends Cuadro{

	public CuadroHierba2(Sprite sprite) {
		super(sprite);
		// TODO Auto-generated constructor stub
	}

}
