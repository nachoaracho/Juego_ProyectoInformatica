package mapa.cuadro;

import graficos.Sprite;

public class CuadroPiedra extends Cuadro {

	public CuadroPiedra(Sprite sprite) {
		super(sprite);
		// TODO Auto-generated constructor stub
	}

}
