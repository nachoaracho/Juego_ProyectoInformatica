package mapa.cuadro;

import graficos.Pantalla;
import graficos.Sprite;

public abstract class Cuadro {
	public int x;
	public int y;
	
	public Sprite sprite;
	
	public static final int LADO=16;
	
	//Coleccion de cuadros
	public static final Cuadro VACIO=new CuadroVacio(Sprite.VACIO);
	public static final Cuadro concreto= new CuadroConcreto(Sprite.concreto);
	public static final Cuadro PASTO1=new CuadroPasto1(Sprite.PASTO1);
	public static final Cuadro PASTO2= new CuadroPasto2(Sprite.PASTO2);
	public static final Cuadro PASTO3=new CuadroPasto3(Sprite.PASTO3);
	public static final Cuadro HIERBA1=new CuadroHierba1(Sprite.HIERBA1);
	public static final Cuadro HIERBA2=new CuadroHierba2(Sprite.HIERBA2);
	public static final Cuadro HIERBA3=new CuadroHierba3(Sprite.HIERBA3);
	public static final Cuadro ARBUSTO=new CuadroArbusto(Sprite.ARBUSTO);
	public static final Cuadro ARBOL=new CuadroArbol(Sprite.ARBOL);
	public static final Cuadro PIEDRA=new CuadroPiedra(Sprite.PIEDRA);
	//fin coleccion
	
	public Cuadro(Sprite sprite) {
		this.sprite=sprite;
	}
	
	public void mostrar(int x, int y, Pantalla pantalla) {
		pantalla.mostrarCuadro(x << 4, y << 4, this);
	}
	
	public boolean solido() {
		return false;
	}
}
