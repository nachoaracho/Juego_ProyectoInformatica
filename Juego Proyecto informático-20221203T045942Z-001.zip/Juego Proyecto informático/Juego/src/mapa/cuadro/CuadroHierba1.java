package mapa.cuadro;

import graficos.Sprite;

public class CuadroHierba1 extends Cuadro{

	public CuadroHierba1(Sprite sprite) {
		super(sprite);
		// TODO Auto-generated constructor stub
	}

}
