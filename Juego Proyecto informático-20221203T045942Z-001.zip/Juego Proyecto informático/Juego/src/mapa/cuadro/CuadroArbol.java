package mapa.cuadro;

import graficos.Sprite;

public class CuadroArbol extends Cuadro {

	public CuadroArbol(Sprite sprite) {
		super(sprite);
		// TODO Auto-generated constructor stub
	}

}
