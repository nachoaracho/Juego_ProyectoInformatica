package mapa.cuadro;

import graficos.Sprite;

public class CuadroPasto3 extends Cuadro {

	public CuadroPasto3(Sprite sprite) {
		super(sprite);
		// TODO Auto-generated constructor stub
	}

}
