package mapa;

import graficos.Pantalla;
import mapa.cuadro.Cuadro;

public abstract class Mapa {
	protected int ancho;
	protected int alto;
	
	protected int[] cuadros;
	
	public Mapa(int ancho, int alto) {
		this.ancho=ancho;
		this.alto=alto;
		
		cuadros = new int[ancho*alto];
		generarMapa();
	}
	
	public Mapa(String ruta) {
		cargarMapa(ruta);
	}
	
	protected void generarMapa() {
		
	}
	
	private void cargarMapa(String ruta) {
		
	}
	
	public void actualizar() {
		
	}
	
	//Temporal
	public void mostrar(int compensacionX, int compensacionY, Pantalla pantalla) {
		
		pantalla.estableceDiferencia(compensacionX, compensacionY);
		
		int o =compensacionX >> 4;
		int es=(compensacionX+pantalla.obtenerAncho()+Cuadro.LADO) >>4;
		int n=compensacionY >>4;
		int s=(compensacionY+pantalla.obtenerAlto()+Cuadro.LADO) >>4;
		
		for(int y=n;y<s;y++) {
			for(int x=o; x<es;x++) {
				obtenCuadro(x,y).mostrar(x, y, pantalla);
			}
		}
	}
	//fin temporal
	
	public Cuadro obtenCuadro(final int x,final int y) {
		if(x<0||y<0||x>=ancho||y>=alto) {
			return Cuadro.VACIO;
		}
		
		switch (cuadros[x+y*ancho]) {
		case 0:
			return Cuadro.concreto;
		case 1:
			return Cuadro.PASTO1;
		case 2:
			return Cuadro.PASTO2;
		case 3:
			return Cuadro.PASTO3;
		case 4:
			return Cuadro.HIERBA1;
		case 5:
			return Cuadro.HIERBA2;
		case 6:
			return Cuadro.HIERBA3;
		case 7:
			return Cuadro.ARBUSTO;
		case 8:
			return Cuadro.ARBOL;
		case 9:
			return Cuadro.PIEDRA;
		default:
			return Cuadro.VACIO;
		}
	}
}
